package com.ridenow.driver.ui

import com.ridenow.driver.R
import androidx.compose.ui.res.stringResource

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ridenow.driver.ui.auth.OtpScreen
import com.ridenow.driver.ui.auth.PhoneScreen
import com.ridenow.driver.ui.auth.formatPhoneForDisplay
import com.ridenow.driver.ui.account.AccountScreen
import com.ridenow.driver.ui.earnings.EarningsScreen
import com.ridenow.driver.ui.home.HomeScreen
import com.ridenow.driver.ui.home.LocalNavBadges
import com.ridenow.driver.ui.home.MainTab
import com.ridenow.driver.ui.intro.IntroScreen
import com.ridenow.driver.ui.registration.ApplicationStatus
import com.ridenow.driver.ui.registration.ApplicationViewModel
import com.ridenow.driver.ui.registration.BackgroundLocationScreen
import com.ridenow.driver.ui.registration.BankAccountScreen
import com.ridenow.driver.ui.registration.IdentityScreen
import com.ridenow.driver.ui.profile.DriverProfileScreen
import com.ridenow.driver.ui.profile.EditProfileScreen
import com.ridenow.driver.ui.registration.LicenseScreen
import com.ridenow.driver.ui.registration.VehicleDocsScreen
import com.ridenow.driver.ui.registration.VehiclePhotosScreen
import com.ridenow.driver.ui.registration.AvailabilityScreen
import com.ridenow.driver.ui.registration.ServiceAreaScreen
import com.ridenow.driver.ui.registration.NotificationPermissionScreen
import com.ridenow.driver.ui.registration.PersonalInfoScreen
import com.ridenow.driver.ui.registration.ReviewItem
import com.ridenow.driver.ui.registration.ReviewScreen
import com.ridenow.driver.ui.registration.TermsScreen
import com.ridenow.driver.ui.registration.VehicleScreen
import com.ridenow.driver.ui.preview.PreviewConfig
import com.ridenow.driver.ui.splash.SplashScreen
import com.ridenow.driver.ui.status.ActionRequiredScreen
import com.ridenow.driver.ui.status.ApprovedScreen
import com.ridenow.driver.ui.status.RejectedScreen
import com.ridenow.driver.ui.status.SubmittedScreen
import com.ridenow.driver.ui.theme.RideTheme
import com.ridenow.driver.ui.theme.ThemeMode
import com.ridenow.driver.ui.trip.TripCompleteScreen
import com.ridenow.driver.ui.trip.TripPhase
import com.ridenow.driver.ui.trip.TripScreen
import kotlinx.coroutines.delay
import com.ridenow.driver.ui.welcome.WelcomeScreen
import com.ridenow.driver.ui.components.initialsOf
import com.ridenow.driver.ui.components.toast
import com.ridenow.driver.ui.data.BankAccountInfo
import com.ridenow.driver.ui.data.Notice
import com.ridenow.driver.ui.legal.LegalAboutScreen
import com.ridenow.driver.ui.legal.LegalDocScreen
import com.ridenow.driver.ui.legal.LegalDocs
import com.ridenow.driver.ui.more.LanguageScreen
import com.ridenow.driver.ui.notifications.NotificationsScreen
import com.ridenow.driver.ui.payouts.BankAccountManageScreen
import com.ridenow.driver.ui.payouts.BankFormScreen
import com.ridenow.driver.ui.payouts.PayoutsScreen
import com.ridenow.driver.ui.earnings.EarningsDetailsScreen
import com.ridenow.driver.ui.rides.RideDetailsScreen
import com.ridenow.driver.ui.rides.RideHistoryScreen
import com.ridenow.driver.ui.settings.AppearanceScreen
import com.ridenow.driver.ui.settings.DeleteAccountScreen
import com.ridenow.driver.ui.settings.NotificationSettingsScreen
import com.ridenow.driver.ui.settings.PaymentMethodsScreen
import com.ridenow.driver.ui.settings.PrivacySecurityScreen
import com.ridenow.driver.ui.settings.SettingsScreen
import com.ridenow.driver.ui.support.EmergencyAssistScreen
import com.ridenow.driver.ui.support.FaqScreen
import com.ridenow.driver.ui.support.HelpSafetyScreen
import com.ridenow.driver.ui.support.NewTicketScreen
import com.ridenow.driver.ui.support.ReportIssueScreen
import com.ridenow.driver.ui.support.SafetyCenterScreen
import com.ridenow.driver.ui.support.ShareTripScreen
import com.ridenow.driver.ui.support.SupportCenterScreen
import com.ridenow.driver.ui.support.TicketConversationScreen
import com.ridenow.driver.ui.support.TicketsScreen
import com.ridenow.driver.ui.theme.AppearanceState
import com.ridenow.driver.ui.theme.MapStyle
import com.ridenow.driver.ui.trip.CompletedTrip
import com.ridenow.driver.ui.vehicle.EditVehicleScreen
import com.ridenow.driver.ui.vehicle.VehicleDetailsScreen
import com.ridenow.driver.ui.vehicle.VehicleDocumentsScreen

enum class Screen {
    Splash, Intro, Welcome, Phone, Otp, Terms, Background, Notifications, Personal, Identity, License, Vehicle,
    VehicleDocs, VehiclePhotos, Availability, ServiceArea, Bank, Review, Submitted,
    ActionRequired, Rejected, Approved, Home, Earnings, Rides, Support, Account, Trip, TripComplete, DriverProfile, EditProfile,
    NotificationCenter, EarningsDetails, RideDetails, VehicleDetails, EditVehicle, VehicleDocuments, Payouts, BankManage, BankForm,
    Settings, Appearance, LanguageSettings, NotificationSettings, Privacy, DeleteAccount, PaymentMethods,
    Faq, Tickets, Conversation, NewTicket, HelpSafety, SafetyCenter, Emergency, ShareTrip, ReportIssue, Legal, LegalDoc,
}

/** Survives activity recreation within one app process, so the splash does not replay on rotation or theme changes. */
private object SessionFlags { var splashDone = false }

// Step numbers used as keys for the Review summaries.
private const val STEP_TERMS = 1
private const val STEP_BACKGROUND = 2
private const val STEP_NOTIFICATIONS = 12
private const val STEP_PERSONAL = 3
private const val STEP_LICENSE = 5
private const val STEP_VEHICLE = 6
private const val STEP_PHOTOS = 8
private const val STEP_AVAILABILITY = 9
private const val STEP_AREA = 10

@Composable
fun AppRoot(appearance: AppearanceState) {
    var screen by rememberSaveable { mutableStateOf(Screen.Splash) }
    var phone by rememberSaveable { mutableStateOf("") }
    // True while the driver is fixing one section from the Review screen: finishing it returns to Review.
    var editing by rememberSaveable { mutableStateOf(false) }
    // Set when Bank account was opened from Home or Account (name of that screen): finishing returns there.
    var bankReturn by rememberSaveable { mutableStateOf<String?>(null) }
    val app: ApplicationViewModel = viewModel()
    val saveable = rememberSaveableStateHolder()
    val shownPhone = formatPhoneForDisplay(phone.ifBlank { "+1 555 012 3456" })
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ridenowdriver", 0) }
    val store = app.store
    val stack = app.stack
    val driverName = app.profileName.ifBlank { app.summaries[STEP_PERSONAL].orEmpty() }
    val initials = initialsOf(driverName)
    var selRide by rememberSaveable { mutableStateOf("") }
    var selTicket by rememberSaveable { mutableStateOf("") }
    var selTopic by rememberSaveable { mutableStateOf(-1) }
    var selDoc by rememberSaveable { mutableStateOf("") }
    var reportCat by rememberSaveable { mutableStateOf(0) }
    var editBankId by rememberSaveable { mutableStateOf(-1) }

    /** Opens a pushed screen and remembers where the driver came from. */
    fun go(target: Screen) { stack.add(screen); screen = target }
    /** Returns to the screen that opened the current one, or Home. */
    fun back() { screen = stack.removeLastOrNull() ?: Screen.Home }
    /** Switches tab and forgets the pushed screens. */
    fun tab(t: MainTab) { stack.clear(); screen = tabScreen(t) }
    fun nowMinute(): Int = java.util.Calendar.getInstance().let { it.get(java.util.Calendar.HOUR_OF_DAY) * 60 + it.get(java.util.Calendar.MINUTE) }
    fun signOut() {
        app.reset(); phone = ""; editing = false; bankReturn = null
        prefs.edit().remove("terms_accepted").remove("application_submitted").apply()
        screen = Screen.Welcome
    }
    fun openNotice(n: Notice) {
        when { n.icon == "wallet" -> go(Screen.Payouts); n.icon == "person" -> tab(MainTab.Home); n.icon == "check" -> tab(MainTab.Rides) }
    }

    // Text for the Review rows that do not come from a screen.
    val accepted = stringResource(R.string.review_accepted)
    val bgOn = stringResource(R.string.review_bg_on)
    val bgOff = stringResource(R.string.review_bg_off)
    val notifOn = stringResource(R.string.review_notif_on)
    val notifOff = stringResource(R.string.review_notif_off)
    val bothSides = stringResource(R.string.review_both_sides)
    val docsDone = stringResource(R.string.review_docs)
    val bankAdded = stringResource(R.string.review_bank_added)
    val bankSkipped = stringResource(R.string.review_bank_skipped)
    val dash = "\u2014"

    // Permissions already granted on this device skip their screens. Re-checked at each step.
    fun backgroundOk(): Boolean = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q ||
        androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_BACKGROUND_LOCATION) ==
        android.content.pm.PackageManager.PERMISSION_GRANTED
    fun notificationsOk(): Boolean = androidx.core.app.NotificationManagerCompat.from(context).areNotificationsEnabled()
    // Where the flow goes after the background-location step (or straight after Terms when that step is skipped).
    fun afterBackground(): Screen {
        if (!notificationsOk()) return Screen.Notifications
        app.summaries[STEP_NOTIFICATIONS] = notifOn
        return Screen.Personal
    }
    fun afterTerms(): Screen {
        if (!backgroundOk()) return Screen.Background
        app.summaries[STEP_BACKGROUND] = bgOn
        return afterBackground()
    }
    val reviewItems = listOf(
        ReviewItem(stringResource(R.string.review_row_terms), "$accepted \u00b7 ${app.summaries[STEP_BACKGROUND] ?: bgOff} \u00b7 ${app.summaries[STEP_NOTIFICATIONS] ?: notifOff}"),
        ReviewItem(stringResource(R.string.review_row_personal), app.summaries[STEP_PERSONAL] ?: dash),
        ReviewItem(stringResource(R.string.review_row_identity), bothSides),
        ReviewItem(stringResource(R.string.review_row_license), app.summaries[STEP_LICENSE] ?: dash),
        ReviewItem(stringResource(R.string.review_row_vehicle), app.summaries[STEP_VEHICLE] ?: dash),
        ReviewItem(stringResource(R.string.review_row_docs), docsDone),
        ReviewItem(stringResource(R.string.review_row_photos), app.summaries[STEP_PHOTOS] ?: dash),
        ReviewItem(stringResource(R.string.review_row_avail), "${app.summaries[STEP_AVAILABILITY] ?: dash} \u00b7 ${app.summaries[STEP_AREA] ?: dash}"),
        ReviewItem(stringResource(R.string.review_row_bank), if (app.bankSaved) bankAdded else bankSkipped, warn = !app.bankSaved, add = !app.bankSaved),
    )
    val editTargets = listOf(
        Screen.Terms, Screen.Personal, Screen.Identity, Screen.License, Screen.Vehicle,
        Screen.VehicleDocs, Screen.VehiclePhotos, Screen.Availability, Screen.Bank,
    )

    /** Goes to [target], or back to Review when a section was opened for editing. */
    fun advance(target: Screen) {
        if (editing) { editing = false; screen = Screen.Review } else screen = target
    }

    fun finishBank(saved: Boolean) {
        if (saved) app.bankSaved = true else if (bankReturn == null) app.bankSaved = false
        val back = bankReturn
        if (back != null) { bankReturn = null; screen = Screen.valueOf(back) } else advance(Screen.Review)
    }
    fun backFromBank() {
        val back = bankReturn
        if (back != null) { bankReturn = null; screen = Screen.valueOf(back) } else advance(Screen.ServiceArea)
    }

    LaunchedEffect(Unit) {
        if (SessionFlags.splashDone && screen == Screen.Splash) {
            screen = if (prefs.getBoolean("intro_seen", false)) Screen.Welcome else Screen.Intro
        }
    }
    Box(Modifier.fillMaxSize()) {
        CompositionLocalProvider(LocalNavBadges provides emptySet()) {
        Crossfade(targetState = screen, animationSpec = tween(400), label = "root") { current ->
            // Keeps typed text, dates and choices when the driver goes back to a screen.
            saveable.SaveableStateProvider(current.name) {
                when (current) {
                    Screen.Splash -> SplashScreen(onFinished = { SessionFlags.splashDone = true; screen = if (prefs.getBoolean("intro_seen", false)) Screen.Welcome else Screen.Intro })
                    Screen.Intro -> IntroScreen(onDone = { prefs.edit().putBoolean("intro_seen", true).commit(); screen = Screen.Welcome })
                    Screen.Welcome -> WelcomeScreen(onGetStarted = { screen = Screen.Phone }, onHaveAccount = { screen = Screen.Phone }, onHelp = { })
                    Screen.Phone -> {
                        BackHandler { screen = Screen.Welcome }
                        PhoneScreen(onBack = { screen = Screen.Welcome }, onCodeSent = { phone = it; screen = Screen.Otp })
                    }
                    Screen.Otp -> {
                        BackHandler { screen = Screen.Phone }
                        OtpScreen(phone = shownPhone, onBack = { screen = Screen.Phone }, onVerified = { screen = Screen.Terms })
                    }
                    Screen.Terms -> {
                        BackHandler { advance(Screen.Otp) }
                        TermsScreen(
                            onBack = { advance(Screen.Otp) },
                            onAccept = { prefs.edit().putBoolean("terms_accepted", true).apply(); app.summaries[STEP_TERMS] = accepted; screen = afterTerms() },
                            onDecline = { editing = false; screen = Screen.Welcome },
                        )
                    }
                    Screen.Background -> {
                        BackHandler { screen = Screen.Terms }
                        BackgroundLocationScreen(
                            onBack = { screen = Screen.Terms },
                            onAllowed = { app.summaries[STEP_BACKGROUND] = bgOn; screen = afterBackground() },
                            onSkip = { app.summaries[STEP_BACKGROUND] = bgOff; screen = afterBackground() },
                        )
                    }
                    Screen.Notifications -> {
                        BackHandler { screen = Screen.Background }
                        NotificationPermissionScreen(
                            onBack = { screen = if (backgroundOk()) Screen.Terms else Screen.Background },
                            onDone = { on -> app.summaries[STEP_NOTIFICATIONS] = if (on) notifOn else notifOff; advance(Screen.Personal) },
                        )
                    }
                    Screen.Personal -> {
                        BackHandler { advance(Screen.Notifications) }
                        PersonalInfoScreen(onBack = { advance(if (!notificationsOk()) (if (backgroundOk()) Screen.Terms else Screen.Background) else Screen.Notifications) }, onDone = { app.summaries[STEP_PERSONAL] = it; advance(Screen.Identity) })
                    }
                    Screen.Identity -> {
                        BackHandler { advance(Screen.Personal) }
                        IdentityScreen(onBack = { advance(Screen.Personal) }, onDone = { advance(Screen.License) })
                    }
                    Screen.License -> {
                        BackHandler { advance(Screen.Identity) }
                        LicenseScreen(onBack = { advance(Screen.Identity) }, onDone = { app.summaries[STEP_LICENSE] = it; advance(Screen.Vehicle) })
                    }
                    Screen.Vehicle -> {
                        BackHandler { advance(Screen.License) }
                        VehicleScreen(onBack = { advance(Screen.License) }, onDone = { app.summaries[STEP_VEHICLE] = it; advance(Screen.VehicleDocs) })
                    }
                    Screen.VehicleDocs -> {
                        BackHandler { advance(Screen.Vehicle) }
                        VehicleDocsScreen(onBack = { advance(Screen.Vehicle) }, onDone = { advance(Screen.VehiclePhotos) })
                    }
                    Screen.VehiclePhotos -> {
                        BackHandler { advance(Screen.VehicleDocs) }
                        VehiclePhotosScreen(onBack = { advance(Screen.VehicleDocs) }, onDone = { app.summaries[STEP_PHOTOS] = it; advance(Screen.Availability) })
                    }
                    Screen.Availability -> {
                        BackHandler { advance(Screen.VehiclePhotos) }
                        AvailabilityScreen(onBack = { advance(Screen.VehiclePhotos) }, onDone = { app.summaries[STEP_AVAILABILITY] = it; advance(Screen.ServiceArea) })
                    }
                    Screen.ServiceArea -> {
                        BackHandler { advance(Screen.Availability) }
                        ServiceAreaScreen(onBack = { advance(Screen.Availability) }, onDone = { app.summaries[STEP_AREA] = it; advance(Screen.Bank) })
                    }
                    Screen.Bank -> {
                        BackHandler { backFromBank() }
                        BankAccountScreen(onBack = { backFromBank() }, onSaved = { h, b, br, n -> store.addBank(h, b, br, n); finishBank(true) }, onSkip = { finishBank(false) })
                    }
                    Screen.Review -> {
                        BackHandler { screen = Screen.Bank }
                        ReviewScreen(
                            items = reviewItems,
                            onEdit = { i -> editing = true; screen = editTargets[i] },
                            onSubmit = { prefs.edit().putBoolean("application_submitted", true).apply(); screen = Screen.Submitted },
                            onBack = { screen = Screen.Bank },
                        )
                    }
                    Screen.Submitted -> {
                        // UI preview: after a few seconds, jump to Home as if the application had been approved.
                        var secondsLeft by remember { mutableIntStateOf(PreviewConfig.SUBMITTED_TO_HOME_SECONDS) }
                        if (PreviewConfig.ENABLED) LaunchedEffect(Unit) {
                            while (secondsLeft > 0) { delay(1000); secondsLeft-- }
                            app.approveDemo(); screen = Screen.Home
                        }
                        SubmittedScreen(
                            name = app.summaries[STEP_PERSONAL].orEmpty().substringBefore(" "), reference = app.reference,
                            onCheckStatus = { app.checkStatus(); screen = screenFor(app.status) }, onSupport = { },
                            previewSecondsLeft = if (PreviewConfig.ENABLED) secondsLeft else null,
                        )
                    }
                    Screen.ActionRequired -> ActionRequiredScreen(
                        // Fixing returns to Review, then Submit sends the application again.
                        onFix = { i -> editing = true; screen = if (i == 0) Screen.Identity else Screen.VehicleDocs },
                        onUpdate = { editing = true; screen = Screen.Identity }, onSupport = { },
                    )
                    Screen.Rejected -> RejectedScreen(onReapply = { editing = false; screen = Screen.Terms }, onSupport = { })
                    Screen.Approved -> ApprovedScreen(onOpenHome = { screen = Screen.Home }, onExplore = { screen = Screen.Home })
                    Screen.Home -> HomeScreen(
                        online = app.online, bankSaved = app.bankSaved, driverName = driverName,
                        onlineSince = app.onlineSince, bankedMillis = app.bankedMillis,
                        onToggle = { if (app.online) app.goOffline() else if (app.bankSaved) app.goOnline() else { bankReturn = Screen.Home.name; screen = Screen.Bank } },
                        onAddBank = { bankReturn = Screen.Home.name; screen = Screen.Bank },
                        onTab = { tab(it) },
                        earnings = app.earnings, trips = app.history.size, request = app.request,
                        onOfferRequest = { app.offerRequest() }, onDecline = { app.declineRequest() },
                        onAccept = { app.acceptRequest(); screen = Screen.Trip },
                        unread = store.unreadCount, onBell = { go(Screen.NotificationCenter) }, onProfile = { go(Screen.DriverProfile) },
                        onCycleMap = { appearance.setMapStyle(MapStyle.entries[(appearance.mapStyle.ordinal + 1) % MapStyle.entries.size]) },
                    )
                    Screen.Earnings -> {
                        BackHandler { tab(MainTab.Home) }
                        EarningsScreen(
                            store, app.onlineMinutes(), store.unreadCount, initials, { tab(it) }, { go(Screen.NotificationCenter) }, { go(Screen.DriverProfile) },
                            onSeeAll = { tab(MainTab.Rides) }, onOpenRide = { selRide = it.id; go(Screen.EarningsDetails) },
                        )
                    }
                    Screen.Rides -> {
                        BackHandler { tab(MainTab.Home) }
                        RideHistoryScreen(store, store.unreadCount, initials, { tab(it) }, { go(Screen.NotificationCenter) }, { go(Screen.DriverProfile) }, { selRide = it.id; go(Screen.RideDetails) })
                    }
                    Screen.Support -> {
                        BackHandler { tab(MainTab.Home) }
                        SupportCenterScreen(
                            store.unreadCount, initials, { tab(it) }, { go(Screen.NotificationCenter) }, { go(Screen.DriverProfile) },
                            onTopic = { selTopic = it; go(Screen.Faq) }, onContact = { go(Screen.NewTicket) }, onTickets = { go(Screen.Tickets) }, onFaqs = { selTopic = -1; go(Screen.Faq) },
                        )
                    }
                    Screen.Trip -> {
                        val trip = app.trip
                        if (trip == null) LaunchedEffect(Unit) { screen = Screen.Home } else {
                            BackHandler { }
                            TripScreen(
                                trip = trip, phase = app.phase,
                                onAdvance = { if (app.phase == TripPhase.InTrip) screen = Screen.TripComplete else app.advanceTrip() },
                                onCancel = { app.cancelTrip(); screen = Screen.Home },
                            )
                        }
                    }
                    Screen.TripComplete -> {
                        val trip = app.trip
                        if (trip == null) LaunchedEffect(Unit) { screen = Screen.Home } else {
                            BackHandler { }
                            TripCompleteScreen(trip = trip, onDone = {
                                store.addFinished(CompletedTrip(trip.rider, trip.pickup, trip.drop, trip.fare, System.currentTimeMillis()), nowMinute())
                                app.finishTrip(); screen = Screen.Home
                            })
                        }
                    }
                    Screen.DriverProfile -> {
                        BackHandler { back() }
                        DriverProfileScreen(
                            store, driverName, shownPhone, app.profileEmail, app.profileAddress, app.status == ApplicationStatus.Approved,
                            onBack = { back() }, onEdit = { go(Screen.EditProfile) }, onEditVehicle = { go(Screen.EditVehicle) }, onDocs = { go(Screen.VehicleDocuments) },
                        )
                    }
                    Screen.EditProfile -> {
                        BackHandler { back() }
                        EditProfileScreen(
                            store, driverName, shownPhone, app.profileEmail, app.profileAddress, onBack = { back() },
                            onSave = { n, p, e, a -> app.profileName = n; if (p.isNotBlank()) phone = p; app.profileEmail = e; app.profileAddress = a; back() },
                        )
                    }
                    Screen.Account -> {
                        BackHandler { tab(MainTab.Home) }
                        AccountScreen(
                            store, driverName, shownPhone, app.online, app.bankSaved, store.unreadCount, { tab(it) }, { go(Screen.NotificationCenter) },
                            onProfile = { go(Screen.DriverProfile) }, onVehicle = { go(Screen.VehicleDetails) }, onDocuments = { go(Screen.VehicleDocuments) },
                            onPayouts = { go(Screen.Payouts) }, onBank = { go(Screen.BankManage) }, onSettings = { go(Screen.Settings) },
                            onNotificationSettings = { go(Screen.NotificationSettings) }, onHelpSafety = { go(Screen.HelpSafety) }, onLegal = { go(Screen.Legal) },
                            onGoOffline = { app.goOffline() }, onSignOut = { signOut() },
                        )
                    }
                    Screen.NotificationCenter -> { BackHandler { back() }; NotificationsScreen(store, { back() }, { openNotice(it) }) }
                    Screen.EarningsDetails -> {
                        BackHandler { back() }
                        val ride = store.rides.firstOrNull { it.id == selRide }
                        if (ride == null) LaunchedEffect(Unit) { back() } else EarningsDetailsScreen(ride, store.sample, { back() }, { reportCat = 0; go(Screen.ReportIssue) })
                    }
                    Screen.RideDetails -> {
                        BackHandler { back() }
                        val ride = store.rides.firstOrNull { it.id == selRide }
                        if (ride == null) LaunchedEffect(Unit) { back() } else RideDetailsScreen(ride, store.sample, { back() }, { reportCat = 0; go(Screen.ReportIssue) })
                    }
                    Screen.VehicleDetails -> { BackHandler { back() }; VehicleDetailsScreen(store, { back() }, { go(Screen.EditVehicle) }, { go(Screen.VehicleDocuments) }) }
                    Screen.EditVehicle -> { BackHandler { back() }; EditVehicleScreen(store, { back() }, { back() }) }
                    Screen.VehicleDocuments -> { BackHandler { back() }; VehicleDocumentsScreen(store, { back() }, { selTopic = 1; go(Screen.Faq) }) }
                    Screen.Payouts -> { BackHandler { back() }; PayoutsScreen(store, { back() }, { selTopic = 2; go(Screen.Faq) }, { editBankId = -1; go(Screen.BankForm) }) }
                    Screen.BankManage -> {
                        BackHandler { back() }
                        BankAccountManageScreen(
                            store, { back() }, { selTopic = 2; go(Screen.Faq) }, onEdit = { editBankId = it.id; go(Screen.BankForm) },
                            onAdd = { editBankId = -1; go(Screen.BankForm) }, onRemoved = { app.bankSaved = store.banks.isNotEmpty(); if (!app.bankSaved && app.online) app.goOffline() },
                        )
                    }
                    Screen.BankForm -> {
                        BackHandler { back() }
                        val existing = store.banks.firstOrNull { it.id == editBankId }
                        BankFormScreen(existing, { back() }, onSave = { h, b, br, n, t ->
                            if (existing != null) { val i = store.banks.indexOf(existing); store.banks[i] = BankAccountInfo(existing.id, h, b, n, br, t) } else store.addBank(h, b, br, n, t)
                            app.bankSaved = true; back()
                        })
                    }
                    Screen.Settings -> {
                        BackHandler { back() }
                        SettingsScreen(
                            store, driverName, shownPhone, appearance.mode, { back() }, onProfile = { go(Screen.DriverProfile) }, onAppearance = { go(Screen.Appearance) },
                            onLanguage = { go(Screen.LanguageSettings) }, onNotifications = { go(Screen.NotificationSettings) }, onPrivacy = { go(Screen.Privacy) },
                            onPaymentMethods = { go(Screen.PaymentMethods) }, onBank = { go(Screen.BankManage) }, onPayouts = { go(Screen.Payouts) },
                            onHelp = { go(Screen.HelpSafety) }, onTickets = { go(Screen.Tickets) }, onAbout = { go(Screen.Legal) }, onSignOut = { signOut() },
                        )
                    }
                    Screen.Appearance -> { BackHandler { back() }; AppearanceScreen(appearance, { back() }) }
                    Screen.LanguageSettings -> { BackHandler { back() }; LanguageScreen { back() } }
                    Screen.NotificationSettings -> { BackHandler { back() }; NotificationSettingsScreen({ back() }) }
                    Screen.Privacy -> { BackHandler { back() }; PrivacySecurityScreen({ back() }, onPersonalData = { go(Screen.DriverProfile) }, onDelete = { go(Screen.DeleteAccount) }) }
                    Screen.PaymentMethods -> { BackHandler { back() }; PaymentMethodsScreen(store, { back() }, { go(Screen.BankManage) }) }
                    Screen.DeleteAccount -> {
                        BackHandler { back() }
                        val requested = stringResource(R.string.priv_download_done)
                        DeleteAccountScreen(
                            { back() }, onDownload = { toast(context, requested) }, onGoOffline = { app.goOffline(); tab(MainTab.Home) },
                            onDelete = { prefs.edit().clear().apply(); app.reset(); phone = ""; editing = false; bankReturn = null; screen = Screen.Welcome },
                        )
                    }
                    Screen.Faq -> { BackHandler { back() }; FaqScreen(selTopic, { back() }, { go(Screen.NewTicket) }) }
                    Screen.Tickets -> {
                        BackHandler { back() }
                        TicketsScreen(store, store.unreadCount, initials, { tab(it) }, { go(Screen.NotificationCenter) }, { go(Screen.DriverProfile) }, { selTicket = it.id; go(Screen.Conversation) }, { go(Screen.NewTicket) })
                    }
                    Screen.Conversation -> {
                        BackHandler { back() }
                        val t = store.tickets.firstOrNull { it.id == selTicket }
                        if (t == null) LaunchedEffect(Unit) { back() } else TicketConversationScreen(t, { back() })
                    }
                    Screen.NewTicket -> { BackHandler { back() }; NewTicketScreen(store, { back() }, onCreated = { t -> selTicket = t.id; screen = Screen.Conversation }) }
                    Screen.HelpSafety -> {
                        BackHandler { back() }
                        HelpSafetyScreen(
                            { back() }, onTopic = { selTopic = it; go(Screen.Faq) }, onSafetyCenter = { go(Screen.SafetyCenter) }, onEmergency = { go(Screen.Emergency) },
                            onShareTrip = { go(Screen.ShareTrip) }, onReportSafety = { reportCat = 5; go(Screen.ReportIssue) }, onContact = { go(Screen.NewTicket) },
                        )
                    }
                    Screen.SafetyCenter -> { BackHandler { back() }; SafetyCenterScreen({ back() }, { go(Screen.Emergency) }, { go(Screen.ShareTrip) }, { reportCat = 5; go(Screen.ReportIssue) }) }
                    Screen.Emergency -> { BackHandler { back() }; EmergencyAssistScreen({ back() }, { reportCat = 5; go(Screen.ReportIssue) }) }
                    Screen.ShareTrip -> { BackHandler { back() }; ShareTripScreen({ back() }) }
                    Screen.ReportIssue -> { BackHandler { back() }; ReportIssueScreen(store, reportCat, { back() }, { screen = Screen.Tickets }) }
                    Screen.Legal -> { BackHandler { back() }; LegalAboutScreen({ back() }, { selDoc = it; go(Screen.LegalDoc) }) }
                    Screen.LegalDoc -> {
                        BackHandler { back() }
                        val doc = LegalDocs.find(selDoc)
                        if (doc == null) LaunchedEffect(Unit) { back() } else LegalDocScreen(doc, { back() })
                    }
                }
            }
        }
        }
    }
}

private fun tabScreen(tab: MainTab): Screen = when (tab) {
    MainTab.Home -> Screen.Home
    MainTab.Earnings -> Screen.Earnings
    MainTab.Rides -> Screen.Rides
    MainTab.Support -> Screen.Support
    MainTab.Account -> Screen.Account
}

private fun screenFor(status: ApplicationStatus): Screen = when (status) {
    ApplicationStatus.Pending -> Screen.Submitted
    ApplicationStatus.ActionRequired -> Screen.ActionRequired
    ApplicationStatus.Rejected -> Screen.Rejected
    ApplicationStatus.Approved -> Screen.Approved
}
